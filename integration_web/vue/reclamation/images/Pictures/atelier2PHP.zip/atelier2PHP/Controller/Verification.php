<?php
require_once '../Model/client.php';
require_once '../Controller/clientC.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lastName = filter_input(INPUT_POST, 'lastName', FILTER_SANITIZE_STRING);
    $firstName = filter_input(INPUT_POST, 'firstName', FILTER_SANITIZE_STRING);
    $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);
    $phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_NUMBER_INT);
    $address = filter_input(INPUT_POST, 'address', FILTER_SANITIZE_STRING);
    $DoB = filter_input(INPUT_POST, 'DoB', FILTER_SANITIZE_STRING);

    if (empty($lastName) || empty($firstName) || empty($password) || empty($phone) || empty($address) || empty($DoB)) {
        echo "One or more required variables are not defined";
        exit;
    }

    if (strlen($password) < 8) {
        echo "Password must be at least 8 characters long";
        exit;
    }

    if (!preg_match('/^[0-9]{10}$/', $phone)) {
        echo "Phone number must be 10 digits long";
        exit;
    }

    if (strlen($DoB) < 10 || strpos($DoB, '-') === false) {
        echo "Date of Birth must be in the format 'YYYY-MM-DD'";
        exit;
    }

    $client = new Client($lastName, $firstName, $password, $phone, $address, $DoB);

    echo "Client Information:\n";
    var_dump($client);

    $clientC = new clientC();
    $clientC->showClient($client);
}

?>