<?php
require_once('../Model/Client.php');

class ClientC {
    public function verifyClient($client) {
        // Vérifier si le client existe dans la base de données
        // Si le client existe, retourner true
        // Sinon, retourner false

        // Exemple de code pour vérifier si le client existe
        $db = new PDO('mysql:host=localhost;dbname=mydb', 'username', 'password');

        $query = $db->prepare('SELECT * FROM Client WHERE lastName = :lastName AND firstName = :firstName AND phone = :phone AND address = :address AND dob = :dob');
        $query->execute([
            'lastName' => $client->getLastName(),
            'firstName' => $client->getFirstName(),
            'phone' => $client->getPhone(),
            'address' => $client->getAddress(),
            'dob' => $client->getDob()
        ]);

        return $query->rowCount() > 0;
    }

    public function showClient($client) {
        // Afficher les informations du client
        echo "Nom: " . $client->getLastName() . "<br>";
        echo "Prénom: " . $client->getFirstName() . "<br>";
        echo "Téléphone: " . $client->getPhone() . "<br>";
        echo "Adresse: " . $client->getAddress() . "<br>";
        echo "Date de naissance: " . $client->getDob() . "<br>";
    }
}