<?php
require_once('../Controller/ClientC.php');

if (isset($_POST['submit'])) {
    $client = new Client($_POST['lastName'], $_POST['firstName'], $_POST['password'], $_POST['phone'], $_POST['address'], $_POST['dob']);

    if ($client->verifyPassword($_POST['password'], $_POST['confirmPassword'])) {
        $clientC = new ClientC();

        if ($clientC->verifyClient($client)) {
            echo "Nom: " . $client->getLastName() . "<br>";
            echo "Prénom: " . $client->getFirstName() . "<br>";
            echo "Téléphone: " . $client->getPhone() . "<br>";
            echo "Adresse: " . $client->getAddress() . "<br>";
            echo "Date de naissance: " . $client->getDob() . "<br>";
        } else {
            echo "Le client n'existe pas.";
        }
    } else {
        echo "Les mots de passe ne correspondent pas.";
    }
} else {
    require_once('../Controller/inscription.php');
}