<?php

class Client {
    public $lastName;
    public $firstName;
    public $password;
    public $phone;
    public $address;
    public $DoB;

    function __construct($lastName, $firstName, $password, $phone, $address, $DoB) {
        $this->lastName = $lastName;
        $this->firstName = $firstName;
        $this->password = $password;
        $this->phone = $phone;
        $this->address = $address;
        $this->DoB = $DoB;
    }

    function showClient() {
        echo "Last Name: " . $this->lastName . "<br>";
        echo "First Name: " . $this->firstName . "<br>";
        echo "Phone: " . $this->phone . "<br>";
        echo "Address: " . $this->address . "<br>";
        echo "Date of Birth: " . $this->DoB . "<br>";
    }

public function getLastName() {
    return $this->lastName;
}

public function getFirstName() {
    return $this->firstName;
}

public function getPassword() {
    return $this->password;
}

public function getPhone() {
    return $this->phone;
}

public function getAddress() {
    return $this->address;
}

public function getDoB() {
    return $this->DoB;
}

public function verifyPassword($password, $confirmPassword) {
    // Vérifier si les mots de passe correspondent
    // Si les mots de passe correspondent, retourner true
    // Sinon, retourner false

    // Exemple de code pour vérifier si les mots de passe correspondent
    return $password === $confirmPassword;
}
}